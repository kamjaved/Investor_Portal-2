module.exports = {
    "mongoUrl": "<enter your mongodb database link here>"
}